## 安装
假设插件名为：yapi-plugin-demo,安装方法如下：
```
cd {项目目录}
yapi plugin yapi-plugin-demo
```

## 卸载插件
假设插件名为：yapi-plugin-demo,卸载方法如下：
```
cd {项目目录}
yapi unplugin yapi-plugin-demo
```