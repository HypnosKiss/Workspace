module.exports = {
  server: false,
  client: true
}